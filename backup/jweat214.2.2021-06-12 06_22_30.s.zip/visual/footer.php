
<DIV align="center" style="padding-top: 30px;">© copyright 2021 &nbsp;|&nbsp; All rights      
 reserved &nbsp;|&nbsp; J W Realty <span style="visibility:hidden;">Developed by <A style="color:#000; font-size: 14px; text-decoration: none;" 
href="https://www.jwresources.sg/" target="_blank">JW      
Resources</A></span></DIV>