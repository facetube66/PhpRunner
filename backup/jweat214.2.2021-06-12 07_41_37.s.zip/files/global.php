<?php
echo "<script src='common.js'></script>";
?>