<BR><BR>
<P align="center">Use <B>admin@test.com/admin</B> to login. This header can be found in Header item on the Editor screen.</P>